import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, Image, View, Switch } from 'react-native';
import { Card } from 'react-native-paper';

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleTheme = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Dynamic styles based on theme
  const containerStyle = isDarkMode ? styles.darkContainer : styles.lightContainer;
  const cardStyle = isDarkMode ? styles.darkCard : styles.lightCard;
  const textStyle = isDarkMode ? styles.darkText : styles.lightText;

  return (
    <SafeAreaView style={[styles.container, containerStyle]}>
      <Card style={[styles.card, cardStyle]}>
        <View style={styles.profileHeader}>
          <Image
            source={{ uri: 'https://via.placeholder.com/150' }} // Replace with your image URL
            style={styles.profileImage}
          />
          <Text style={[styles.name, textStyle]}>Ahmed Ali Raja</Text>
          <Text style={[styles.profession, textStyle]}>Student</Text>
        </View>
        <View style={styles.themeToggle}>
          <Text style={textStyle}>{isDarkMode ? 'Dark Mode' : 'Light Mode'}</Text>
          <Switch
            value={isDarkMode}
            onValueChange={toggleTheme}
            thumbColor={isDarkMode ? '#fff' : '#f5f5f5'}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
          />
        </View>
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  lightContainer: {
    backgroundColor: '#ecf0f1',
  },
  darkContainer: {
    backgroundColor: '#121212',
  },
  card: {
    padding: 16,
    borderRadius: 8,
    elevation: 4,
  },
  lightCard: {
    backgroundColor: '#fff',
  },
  darkCard: {
    backgroundColor: '#1e1e1e',
  },
  profileHeader: {
    alignItems: 'center',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  lightText: {
    color: '#000',
  },
  darkText: {
    color: '#fff',
  },
  profession: {
    fontSize: 18,
  },
  themeToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
  },
});