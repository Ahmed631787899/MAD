import React, { useState } from 'react';
import { Text, View, TextInput, Button, StyleSheet, SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Step 1: Name Screen
const NameScreen = ({ navigation }) => {
  const [name, setName] = useState('');

  const handleNext = () => {
    if (!name) {
      alert('Please enter your name');
      return;
    }
    navigation.navigate('Email', { name });
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Enter Your Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={name}
        onChangeText={setName}
      />
      <Button title="Next" onPress={handleNext} />
    </SafeAreaView>
  );
};

// Step 2: Email Screen
const EmailScreen = ({ navigation, route }) => {
  const [email, setEmail] = useState('');
  const { name } = route.params;

  const handleNext = () => {
    if (!email) {
      alert('Please enter your email');
      return;
    }
    navigation.navigate('RegNo', { name, email });
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Enter Your Email</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <Button title="Next" onPress={handleNext} />
    </SafeAreaView>
  );
};

// Step 3: Registration Number Screen
const RegNoScreen = ({ navigation, route }) => {
  const [regNo, setRegNo] = useState('');
  const { name, email } = route.params;

  const handleNext = () => {
    if (!regNo) {
      alert('Please enter your registration number');
      return;
    }
    navigation.navigate('Password', { name, email, regNo });
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Enter Your Registration Number</Text>
      <TextInput
        style={styles.input}
        placeholder="Registration Number"
        value={regNo}
        onChangeText={setRegNo}
        keyboardType="numeric"
      />
      <Button title="Next" onPress={handleNext} />
    </SafeAreaView>
  );
};

// Step 4: Password Screen
const PasswordScreen = ({ navigation, route }) => {
  const [password, setPassword] = useState('');
  const { name, email, regNo } = route.params;

  const handleSubmit = () => {
    if (!password) {
      alert('Please enter your password');
      return;
    }
    // Submit all data (you can send it to an API or log it)
    console.log({ name, email, regNo, password });
    alert('Registration Successful!');
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Create a Password</Text>
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="Submit" onPress={handleSubmit} />
    </SafeAreaView>
  );
};

// Create Stack Navigator
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#6200ee' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen name="Name" component={NameScreen} options={{ title: 'Step 1: Name' }} />
        <Stack.Screen name="Email" component={EmailScreen} options={{ title: 'Step 2: Email' }} />
        <Stack.Screen name="RegNo" component={RegNoScreen} options={{ title: 'Step 3: Reg No' }} />
        <Stack.Screen name="Password" component={PasswordScreen} options={{ title: 'Step 4: Password' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    marginBottom: 16,
    paddingHorizontal: 8,
    backgroundColor: '#fff',
  },
});